<template>
  <div class="header">
		<form @submit.prevent="submitData">
			<div class="formBook">
				<label>Name: </label>
				<input v-model="name" type="text" /> 
			</div>
				<div class="formBook">
				<label>Book Name: </label>
				<input v-model="bookName" type="text" /> 
			</div>
				<div class="formBook">
				<label>Description: </label>
			<input v-model="description" type="textarea" /> 
			</div>
			<button type="submit">Submit</button>
		</form>
	</div>
</template>

<script>
import { defineComponent, toRefs, reactive } from 'vue'
import useEmitter from '@/composables/useEmitter'

export default defineComponent({
	name: "BookForm",
	setup() {
		const bus = useEmitter()
		const data = reactive ({
			name: '',
			bookName: '',
			description: '',
		})

		const submitData = () => {
      bus.emit("bookItem", {
				name: data.name,
				bookName: data.bookName,
				description: data.description,
			});
      data.name = '' 
      data.bookName = ''
      data.description = ''
			// /* eslint-disable no-debugger */
      //   debugger
		}

		return {
			submitData,
			...toRefs(data),
		}
	},
})
</script>

<style scoped lang="scss">
.header {
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.26);
	padding: 30px;
	form {
		.formBook {
			margin: 10px;
			input {
				width: 100%;
			}
		}
		button {
			padding: 10px;
			background-color: blueviolet;
			color: white;
		}
	}
}
</style>