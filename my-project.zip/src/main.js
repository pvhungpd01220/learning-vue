import { createApp } from 'vue'
import App from './App.vue'
import { createRouter, createWebHistory } from 'vue-router';

import ListFriend from './components/friend-contact/ListFriend.vue'
import SurveyLearning from './components/survey/SurveyLearning.vue'
import ListGoal from './components/ListGoal.vue'
import ListTeam from './components/team/ListTeam.vue'
import TeamDetail from './components/team/TeamDetail.vue'
import UserDetail from './components/team/UserDetail.vue'
import Book from './components/books/Book.vue'

const router = createRouter({
    history: createWebHistory(),
    routes: [
      { path: '/friends', component: ListFriend }, // our-domain.com/friends => ListFriend
      { path: '/surveys', component: SurveyLearning },
      { path: '/listgoals', component: ListGoal },
      { path: '/teams', component: ListTeam },
      { path: '/teams/:teamId', component: TeamDetail },
      { path: '/users/:userId', component: UserDetail }, // sai o day, thieu user Id
      { path: '/books', component: Book },

    ],
    linkActiveClass: 'active',
  });
  
const app = createApp(App)
app.use(router);
app.mount('#app');
  